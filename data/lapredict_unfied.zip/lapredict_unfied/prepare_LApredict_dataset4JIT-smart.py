import copy
import pickle
import json
import re


def extract_code_segments(input_str):
    # Initialize dictionary with sets for added_code and removed_code
    dic = {'added_code': set(), 'removed_code': set()}

    # Split the input string by 'added_code' and 'removed_code' markers
    segments = re.split(r'(added_code:|removed_code:)', input_str)

    current_segment = None
    for segment in segments:
        segment = segment.strip()
        if segment == 'added_code:':
            current_segment = 'added_code'
        elif segment == 'removed_code:':
            current_segment = 'removed_code'
        elif current_segment:
            if segment:
                dic[current_segment].add(segment)

    return dic


# # Sample input string with multiple added_code and removed_code segments
# input_str = """added_code:  background - color : var ( - - vote - color - approved ) ; background - color : var ( - - vote - color - rejected ) ; added_code: background - color : var ( - - vote - color - recommended ) ; background - color : var ( - - vote - color - disliked ) ; removed_code:  background - color : var ( - - vote - color - max ) ; background - color : var ( - - vote - color - min ) ; removed_code: background - color : var ( - - vote - color - positive ) ; background - color : var ( - - vote - color - negative ) ;"""
#
# # Extract code segments
# result = extract_code_segments(input_str)
# print(result)


projects = ["gerrit", "go", "jdt", "openstack", "platform", "qt"]
partitions = ["train", "val", "test"]

# src_folder = f"/home/zangtao/Liang/DP/sim-com/data/commit_cotents/processed_data/{project}"
# ref_folder = f"/home/zangtao/Liang/DP/jit-smart/data/data/jitfine/inherit_clone_with_IL_modified0/{project}"
# tgt_folder = f"/home/zangtao/Liang/DP/jit-smart/data/data/jitfine/inherit_clone_with_IL_modified0/{project}"

for project in projects:
    for partition in partitions:
        src_file = f"/home/zangtao/Liang/DP/sim-com/data/commit_cotents/processed_data/{project}/val_train/{project}_{partition}.pkl"
        if partition == 'test':
            src_file = f"/home/zangtao/Liang/DP/sim-com/data/commit_cotents/processed_data/{project}/{project}_{partition}.pkl"
        if partition == 'val':
            partition = 'valid'
        ref_file = f"/home/zangtao/Liang/DP/jit-smart/data/data/jitfine/inherit_clone_with_IL_modified0/{project}/changes_{partition}.jsonl"
        tgt_file = f"/home/zangtao/Liang/DP/jit-smart/data/data/jitfine/inherit_clone_with_IL_modified0/{project}/changes_{partition}.pkl"

        with open(src_file, "rb") as src, open(ref_file, "r") as ref, open(tgt_file, "wb") as tgt:
            src_data = pickle.load(src)
            tgt_data = copy.deepcopy(src_data)
            count = 0
            for idx, line in enumerate(ref.readlines()):
                changes_dict = {'added_code': set(), 'removed_code': set()}
                line_data = json.loads(line)
                label_src = src_data[1][idx]
                lab_ref = line_data['y']
                if label_src != lab_ref:
                    tgt_data[1][idx] = lab_ref
                    count += 1
                for change in src_data[3][idx]:
                    change_dict = extract_code_segments(change)
                    for key in change_dict:
                        changes_dict[key].update(change_dict[key])
                tgt_data[3][idx] = changes_dict
            pickle.dump(tgt_data, tgt)
            print(f"Unified {count} samples in {partition} of {project}")